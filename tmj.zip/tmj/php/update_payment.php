<?php
error_reporting(0);
include_once("dbconnect.php");
$userid = $_GET['userid'];
$mobile = $_GET['mobile'];
$amount = $_GET['amount'];
$curcredit = $_GET['curcredit'];

$data = array(
    'id' =>  $_GET['billplz']['id'],
    'paid_at' => $_GET['billplz']['paid_at'] ,
    'paid' => $_GET['billplz']['paid'],
    'x_signature' => $_GET['billplz']['x_signature']
);

$paidstatus = $_GET['billplz']['paid'];
if ($paidstatus=="true"){
    $paidstatus = "Success";
}else{
    $paidstatus = "Failed";
}
$receiptid = $_GET['billplz']['id'];
$signing = '';
foreach ($data as $key => $value) {
    $signing.= 'billplz'.$key . $value;
    if ($key === 'paid') {
        break;
    } else {
        $signing .= '|';
    }
}
 
 
$signed= hash_hmac('sha256', $signing, 'S-yT78hJJhq98pHBvB-X1dYg');
if ($signed === $data['x_signature']) {
    if ($paidstatus == "Success"){ //payment success
        $newcredit = ($amount) + $curcredit;
        $updatecrsql = "UPDATE `tbl_users` SET `users_credit`='$newcredit' WHERE user_email = '$userid'";
        $conn->query($updatecrsql);
        echo 'Payment Success!';
    }
    else 
    {
        echo 'Payment Failed!';
    }
}

?>