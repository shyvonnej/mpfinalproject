<?php

    $servername = "localhost";
    $username = "id18340148_tmj_final";
    $password = "&Qei-_IPc!9c7w=]";
    $dbname = "id18340148_tmj_project";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn -> connect_error)
    {
        die("Connection failed: " . $conn -> connect_error);
    }

?>