<?php

include_once ("dbconnect.php");
$id = $_POST['user_id'];

    if (isset($id)){
        $sql = "SELECT * FROM tbl_payment WHERE user_id = '$id'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0)
    {
        $response["payment"] = array();
        while ($row = $result->fetch_assoc())
        {
            $paymentlist = array();
            $paymentlist["order_id"] = $row["ORDER_ID"];
            $paymentlist["bill_id"] = $row["BILL_ID"];
            $paymentlist["total"] = $row["TOTAL"];
            $paymentlist["date"] = $row["DATE"];
            array_push($response["payment"], $paymentlist);
            echo json_encode($paymentlist);
        }
        echo json_encode($response);
    }
    } else {
        echo "no data";
    }
    $conn->close();
?>