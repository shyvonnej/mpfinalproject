<?php
error_reporting(0);

$name = $_GET['name']; 
$amount = $_GET['amount']; 

$api_key = 'e12a5a5e-e3c2-45f1-b6ff-88525eca02cf';
$collection_id = 'f3qxevvy';
$host = 'https://billplz-staging.herokuapp.com/api/v3/bills';


$data = array(
          'collection_id' => $collection_id,
          'name' => $name,
          'amount' => $amount * 100,
		  'description' => 'Payment for order by '.$name,
          'callback_url' => "https://tmjproject.000webhostapp.com/tmj/return_url",
          'redirect_url' => "https://tmjproject.000webhostapp.com/tmj/php/update_payment.php?name=$name&amount=$amount" 
);


$process = curl_init($host);
curl_setopt($process, CURLOPT_HEADER, 0);
curl_setopt($process, CURLOPT_USERPWD, $api_key . ":");
curl_setopt($process, CURLOPT_TIMEOUT, 30);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($process, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($process, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($process, CURLOPT_POSTFIELDS, http_build_query($data)); 

$return = curl_exec($process);
curl_close($process);

$bill = json_decode($return, true);
header("Location: {$bill['url']}");
?>