<?php

    include_once ("dbconnect.php");
    $email = $_POST['user_email'];

    $sql = "SELECT p.prid, p.prname, p.prprice, p.prqty, c.cart_quantity 
            FROM tbl_products p, tbl_cart c
            WHERE p.prid = c.prid AND c.user_email = '$email'";


    $result = $conn->query($sql);
    $cartlist = $result -> fetch_all(MYSQLI_ASSOC);

    if (count($cartlist) != 0) {
        $response = array('status' => 'success', 'cart' => $cartlist);
        sendJsonResponse($response);
    } else {
        echo "Cart Empty";
    }

    function sendJsonResponse($sentArray)
    {
        header('Content-Type: application/json');
        echo json_encode($sentArray);
    }

?>